function doblue(){
var can1= document.getElementById("can");
  can1.style.backgroundColor="blue";
}

  function docolor(){
 var color1= document.getElementById("can"); 
  var dd1= document.getElementById("d2");
  
    color1.style.backgroundColor= dd1.value;
}
function dosquare(){
var can1= document.getElementById("can");
var sldr1= document.getElementById("sldr");
  len= sldr1.value;
  var ctx= can1.getContext("2d");  ctx.clearRect(0,0,can1.width, can1.height);
  ctx.fillStyle="yellow";
ctx.fillRect(10,10,len,len);

  
}